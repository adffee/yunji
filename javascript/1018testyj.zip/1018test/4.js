'use sttict';

let tot = 0;

for (let i = 3; i< 101; i++){
    if (i%3 == 0) {
        tot += i;
    }
} console.log(tot);