'use strict';

let num1, num2;
let sum = 0;


num1 = +prompt('정수를 입력하세요');
num2 = +prompt('정수를 입력하세요');

sum = alert(`${num1 + num2}`);

for (; ;) {
    num1 = +prompt('정수를 입력하세요');
    if (num1 > 0) {
        num2 = +prompt('정수를 입력하세요 '); {
            if (num2 > 0) {
                sum = alert(`${num1 + num2}`);
            }
        }
    } else {
        alert('정수를 입력하세요 ');
    }




    // for (; ;) {
    //     num1 = +prompt('정수를 입력하세요');
    //     if (num1 < 0) {
    //         alert('정수를 입력하세요 ');
    //         break;
    //     } else {
    //         num2 = +prompt('정수를 입력하세요 '); {
    //             if (num2 < 0) {
    //                 alert('정수를 입력하세요 ');
    //                 break;
    //             }
    //         }
    //     } sum = alert(`${num1 + num2}`);
    // }
    // }