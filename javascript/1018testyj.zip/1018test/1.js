'use strict';

let tot = 0;

for (let i = 1; i < 21; i++){
    tot += i;
}

console.log(tot);