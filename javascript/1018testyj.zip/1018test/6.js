'use strict';

const array = [ ];

for (let i = 0; i < 11; i++){
    array[i] = i;
}
console.log(array);
