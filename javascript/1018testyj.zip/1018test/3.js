'use strict';


let num1, num2;
let sum = 0;

num1 = +prompt('정수를 입력하세요 ');
num2 = +prompt('정수를 입력하세요 ');
sum = alert(`두 수의 합${num1+num2}는 20보다 ${num1 + num2 > 20 ? '큽니다' : '작습니다'}`);


// sum = alert(`${ num1+num2 >20? '큽니다':'작습니다'}`);




