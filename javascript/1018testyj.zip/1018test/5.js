'use strict';


let num1, num2, num3;
let av;


for (; ;){
    num1 = +prompt('숫자를 입력하세요'); {
    if (num1>0) {
        num2 = +prompt('숫자를 입력하세요'); {
            if (num2 > 0) {
                num3 = +prompt('숫자를 입력하세요');
            } if (num3 > 0) {
                av = (num1 + num2 + num3) / 3;
                break;
            }
        }
    }
    } 
} alert(`평균: ${av}`);
